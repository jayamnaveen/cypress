module.exports = {
    RESULTPAGE:{
        SEARCH_RESULT_FIRST: "div.rc"
    } 
}