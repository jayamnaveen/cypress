module.exports = {
    HOMEPAGE:{
        SEARCH_TXTBOX: "input[name='q']",
        SEARCH_TXTBOX_XPATH: "//input[contains(@name,'q')]"
    } 
}